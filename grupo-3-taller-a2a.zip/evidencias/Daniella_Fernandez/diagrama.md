---
config:
  flowchart:
    curve: linear
---
graph TD;
        __start__([<p>__start__</p>]):::first
        model(model)
        tools(tools<hr/><small><em>__tools = lista_equipaje</em></small>)
        __end__([<p>__end__</p>]):::last
        __start__ --> model;
        model -.-> __end__;
        model -.-> tools;
        tools -.-> model;
        classDef default fill:#f2f0ff,line-height:1.2
        classDef first fill-opacity:0
        classDef last fill:#bfb6fc